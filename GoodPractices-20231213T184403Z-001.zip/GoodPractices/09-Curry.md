# ¿Qué es Curryng?

“Currying” es la técnica utilizada en programación funcional que transforma una función que recibe múltiples argumentos en una secuencia de funciones que recibe un solo argumento.

El nombre es en honor al matemático estadounidense Haskell Curry (el otro nombre propuesto fue Schönfinkelisation).

## Un ejemplo

```js
// ES5
const sum = function (a, b) {
  return a + b;
};

// ES6
const sum = (a, b) => a + b;

// Invocación:
sum(2, 3); // 5
```

## Versión currificada

```js
// ES5
const curriedSum = function (a) {
  return function (b) {
    return a + b;
  };
};

// ES6
const curriedSum = (a) => (b) => a + b;

// Invocación:
curriedSum(2)(3); // 5
// O también
const sum2 = curriedSum(2);
console.dir(sum2); // 0: Closure (curriedSum) {a: 2}
sum2(3); // 5
```

## Ventajas del Currying

- Permite utilizar el concepto DRY (don't repeat yourself), al poder crear funciones nuevas simplemente pasando nuestras funciones de base con algunos parámetros, evitando pasar la misma variable una y otra vez.
- Se pueden escribir pequeñas piezas de código que sean más fácil de reutilizar (funciones de orden superior).
- Nos da la posibilidad de crear funciones configurables que pueden ser utilizadas en distintos puntos de nuestro programa hasta conseguir el resultado final.

## Otro ejemplo
```js
// De la forma tradicional:
const isDivisible = (a, b) => b % a === 0;

console.log(isDivisible(2, 8)); // true
console.log(isDivisible(2, 16)); // true

// Utilizando Currying:
const curriedIsDivisible = (a) => b => b % a === 0;
const isDivisibleBy2 = curriedIsDivisible(2);

console.log(isDivisibleBy2(8)); // true
console.log(isDivisibleBy2(16)); // true
```